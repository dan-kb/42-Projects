/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_strrchr.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/23 14:17:09 by dbanifat          #+#    #+#             */
/*   Updated: 2016/09/23 15:04:35 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char	*ft_strrchr(char *s, int c);

int		main(void)
{
	char *s;

	s = "Banana benene binini bonono bununu";
	printf("%p\n", strrchr(s, 'B'));
	printf("%p\n", ft_strrchr(s, 'B'));
	return (0);
}

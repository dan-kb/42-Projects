/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_memccpy.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/25 16:39:19 by dbanifat          #+#    #+#             */
/*   Updated: 2016/09/25 17:34:08 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

void	*ft_memccpy(void *dst, const void *src, int c, size_t n);

int		main(void)
{
	char src[] = "Bana?na";
	char dst[] = "Hi my name is Daniel";
	printf("%p\n", memccpy(dst, src, '?', 7));
	printf("%p\n", ft_memccpy(dst, src, '?', 7));
	return (0);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_strncpy.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/16 20:53:30 by dbanifat          #+#    #+#             */
/*   Updated: 2016/10/02 10:41:21 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char    *ft_strncpy(char *dest, char *src, unsigned int n);

int		main(void)
{
	char src[] = "stars";
	char dst1[30];
	char dst2[30];

	printf("%s\n", strncpy(dst1, src, 6));
	printf("%s\n", ft_strncpy(dst2, src, 6));
	return (0);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_memchr.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/23 12:13:43 by dbanifat          #+#    #+#             */
/*   Updated: 2016/09/23 14:00:36 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

void	*ft_memchr(void *s, int c, size_t n);

int		main(void)
{
	printf("%p\n", memchr("Banana bonono binini benene bununu", 'a', 34));
	printf("%p\n", ft_memchr("Banana bonono binini benene bununu", 'a', 34));
	return (0);
}

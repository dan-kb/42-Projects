/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_tolower.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/23 11:48:34 by dbanifat          #+#    #+#             */
/*   Updated: 2016/09/23 11:52:26 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <ctype.h>
#include <stdio.h>

int		ft_tolower(int c);

int		main(void)
{
	printf("%c\n", tolower('Z'));
	printf("%c\n", ft_tolower('Z'));
	return (0);
}

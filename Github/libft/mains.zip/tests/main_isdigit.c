/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_isdigit.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/22 15:09:08 by dbanifat          #+#    #+#             */
/*   Updated: 2016/09/22 15:27:25 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <ctype.h>
#include <stdio.h>

int		ft_isdigit(int c);

int		main(void)
{
	printf("%d\n", isdigit(49));
	printf("%d\n", ft_isdigit(49));
	return (0);
}

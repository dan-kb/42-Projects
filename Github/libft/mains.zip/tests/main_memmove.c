/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_memmove.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/24 16:35:24 by dbanifat          #+#    #+#             */
/*   Updated: 2016/10/01 14:15:46 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

void	*ft_memmove(void *dst, const void *src, size_t len);

int		main(void)
{
	char src[0xF0] = "hello world";
	char src2[0xF0] = "hello world";


	printf("sizeof(src): %zu\n", sizeof(src));
	printf("%s\n", memmove((void*)src, (src + 2), 7));
	printf("%s\n", ft_memmove((void*)src2, (src2 + 2), 7));
	return (0);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_isascii.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/23 11:57:06 by dbanifat          #+#    #+#             */
/*   Updated: 2016/09/23 12:13:02 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <ctype.h>
#include <stdio.h>

int		ft_isascii(int c);

int		main(void)
{
	printf("%d\n", isascii(128));
	printf("%d\n", ft_isascii(128));
	return (0);
}

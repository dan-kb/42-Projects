/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_strnstr.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/25 17:36:08 by dbanifat          #+#    #+#             */
/*   Updated: 2016/10/03 13:46:54 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char	*ft_strnstr(const char *big, const char *little, size_t len);

int		main(void)
{
	char big[] = "un deux 9";
	char little[] = "deux";
	printf("%p\n", strnstr(big, little, 5));
	printf("%p\n", ft_strnstr(big, little, 5));
	return (0);
}

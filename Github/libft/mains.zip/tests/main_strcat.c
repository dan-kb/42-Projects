/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_strcat.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/24 15:35:54 by dbanifat          #+#    #+#             */
/*   Updated: 2016/09/24 16:30:27 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char	*ft_strcat(char *s1, const char *s2);

int		main(void)
{
	char s1[40] = "Hello, my name is ";
	char s2[40] = "Hello, my name is ";
	char *s3;

	s3 = "Daniel";
	printf("%s\n", strcat(s1, s3));
	printf("%s\n", ft_strcat(s2, s3));
	return (0);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_strjoin.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/26 18:47:47 by dbanifat          #+#    #+#             */
/*   Updated: 2016/09/30 13:17:03 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strjoin(char const *s1, char const *s2);

int		main(void)
{
	char s1[] = "Hi, my name is ";
	char s2[] = "Daniel.";

	printf("%s\n", ft_strjoin(s1, s2));
}

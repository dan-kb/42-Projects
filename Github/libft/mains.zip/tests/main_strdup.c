/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_strdup.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/17 09:46:16 by dbanifat          #+#    #+#             */
/*   Updated: 2016/08/18 16:50:00 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char	*ft_strdup(char *src);

int		main(void)
{
	char src[] = "slakjdfhkaseh";

	printf("%s\n", strdup(src));
	printf("%s\n", ft_strdup(src));
	return (0);
}

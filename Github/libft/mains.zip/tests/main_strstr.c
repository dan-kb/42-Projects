/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_strstr.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/16 21:53:24 by dbanifat          #+#    #+#             */
/*   Updated: 2016/10/01 10:38:46 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

char    *ft_strstr(char *str, char *to_find);

int		main(void)
{
	char str[] = "Hello World!";
	char to_find[] = "World";
	printf("%s\n", strstr(str, to_find));
	printf("%s\n", ft_strstr(str, to_find));
	return (0);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_strlcat.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/24 18:47:52 by dbanifat          #+#    #+#             */
/*   Updated: 2016/10/02 17:31:57 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../libft.h"
#include <stdio.h>
#include <string.h>

size_t	ft_strlcat(char *dst, const char *src, size_t size);

int		main(void)
{
	char dst1[10];
	char dst2[10];
	char *src;
   
	src = "ccc";
	ft_bzero(dst1, 10);
	ft_bzero(dst2, 10);
//	ft_strcpy(dst1, "abc");
//	ft_strcpy(dst2, "abc");
	ft_memset(dst1, 'a', 10);
	ft_memset(dst2, 'a', 10);
	printf("%lu\n", strlcat("abc\0\0\0", src, 0));
	printf("STRLCAT: %s\n", dst1);
	printf("%zu\n", ft_strlcat("abc\0\0\0", src, 0));
	printf("FT_STRLCAT: %s\n", dst2);
	return (0);
}

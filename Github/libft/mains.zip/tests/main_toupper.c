/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_toupper.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/23 11:41:09 by dbanifat          #+#    #+#             */
/*   Updated: 2016/09/23 11:47:09 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <ctype.h>
#include <stdio.h>

int		ft_toupper(int c);

int		main(void)
{
	printf("%c\n", toupper('z'));
	printf("%c\n", ft_toupper('z'));
	return (0);
}

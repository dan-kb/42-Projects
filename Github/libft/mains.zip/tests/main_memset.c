/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_memset.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/21 14:48:53 by dbanifat          #+#    #+#             */
/*   Updated: 2016/09/26 14:30:40 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

void	*ft_memset(void *b, int c, size_t n);

int		main(void)
{
	char str[] = "Banana banana. Banana? Banana!";

	printf("%s\n", memset(str, '$', 6));
	printf("%s\n", ft_memset(str, '$', 6));
}

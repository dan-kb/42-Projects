/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_strsub.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/26 18:08:53 by dbanifat          #+#    #+#             */
/*   Updated: 2016/09/26 18:27:01 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

char	*ft_strsub(char const *s, unsigned int start, size_t len);

int		main(void)
{
	char str[] = "Hello, my name is Daniel";
	printf("%s\n", ft_strsub(str, 18, 6));
	return (0);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_strsplit.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/27 15:35:58 by dbanifat          #+#    #+#             */
/*   Updated: 2016/10/03 20:21:39 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../libft.h"
#include <stdio.h>

int		main(void)
{
	int		i;
	char	**s = ft_strsplit("      split       this for   me  !", ' ');

	i = 0;	
	while (s[i])
		printf("%s\n", s[i++]);
	return (0);
}

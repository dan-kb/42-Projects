/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_strncat.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/25 18:26:03 by dbanifat          #+#    #+#             */
/*   Updated: 2016/09/25 18:40:01 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

char	*ft_strncat(char *s1, const char *s2, size_t n);

int		main(void)
{
	char s1[40] = "Hello, my name is ";
	char s2[40] = "Hello, my name is ";
	char *s3;

	s3 = "Daniel";
	printf("%s\n", strncat(s1, s3, 5));
	printf("%s\n", ft_strncat(s2, s3, 5));
	return (0);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_isprint.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/22 16:22:51 by dbanifat          #+#    #+#             */
/*   Updated: 2016/09/23 11:35:22 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <ctype.h>
#include <stdio.h>

int		ft_isprint(int c);

int		main(void)
{
	printf("%d\n", isprint(-58));
	printf("%d\n", ft_isprint(-58));
	return (0);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_bzero.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/21 16:28:02 by dbanifat          #+#    #+#             */
/*   Updated: 2016/09/22 13:09:50 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>
#include <unistd.h>

void	ft_bzero(void *s, size_t n);

int		main(void)
{
	char str[] = "Banana! BANANA";
	bzero(str, 3);
	printf("%s\n", str);
	ft_bzero(str, 3);
	printf("%s\n", str);
	write(1, &str, 15);
	return (0);
}

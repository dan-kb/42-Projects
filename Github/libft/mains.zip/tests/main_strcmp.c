/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_strcmp.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/17 00:30:09 by dbanifat          #+#    #+#             */
/*   Updated: 2016/08/17 22:08:36 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

int	ft_strcmp(char *s1, char *s2);

int	main(void)
{
	char s1[] = "Helli";
	char s2[] = "Hello";

	printf("%d\n", strcmp(s1, s2));
	printf(“%d\n”, ft_strcmp(s1, s2));
	return (0);
}

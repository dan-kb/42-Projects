/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_strchr.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/23 14:05:22 by dbanifat          #+#    #+#             */
/*   Updated: 2016/09/23 14:16:09 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <string.h>
#include <stdio.h>

char	*ft_strchr(char *s, int c);

int		main(void)
{
	char *s;

	s = "Banana benene binini bonono bununu";
	printf("%p\n", strchr(s, 'a'));
	printf("%p\n", ft_strchr(s, 'a'));
	return (0);
}

/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_memalloc.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/26 13:13:11 by dbanifat          #+#    #+#             */
/*   Updated: 2016/09/26 13:49:05 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <stdlib.h>

void	*ft_memalloc(size_t size);

int		main(void)
{
	printf("%p\n", malloc(0));
	printf("%p\n", ft_memalloc(0));
	return (0);
}

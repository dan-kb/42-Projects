/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_strcpy.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/08/15 21:53:19 by dbanifat          #+#    #+#             */
/*   Updated: 2016/08/16 00:13:12 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_strcpy.c"
#include <string.h>
#include <stdio.h>

int main(void)
{
	char src[] = "a bigger one on my ";
	char dest[] = "an even on my ";

	//printf("%s\n", strcpy(dest, src));
	printf("%s", ft_strcpy(dest, src));
	return (0);
}

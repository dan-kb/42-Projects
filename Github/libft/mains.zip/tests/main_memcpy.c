/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_memcpy.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/22 13:10:49 by dbanifat          #+#    #+#             */
/*   Updated: 2016/09/22 14:46:10 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <string.h>

void	*ft_memcpy(void *dst, const void *src, size_t n);

int		main(void)
{
	char dst1[] = "banana";
	char dst2[] = "banana";
	char src[] = "BANANA";
	memcpy(dst1, src, 2);
	printf("%s\n", dst1);
	ft_memcpy(dst2, src, 2);
	printf("%s\n", dst2);
	return (0);
}

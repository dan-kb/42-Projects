/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main_strtrim.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: dbanifat <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2016/09/27 15:17:05 by dbanifat          #+#    #+#             */
/*   Updated: 2016/10/02 11:47:50 by dbanifat         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../libft.h"
#include <stdio.h>
#include <string.h>

char	*ft_strtrim(char const *s);

int		main(void)
{
	char s[] = "\t\n  \tAAA \t BBB\t\n  \t";
	printf("%s\n", ft_strtrim(s));
	printf("%s\n", "AAA \t BBB");
	printf("%d\n", ft_strcmp(s, "AAA \t BBB"));
	return (0);
}
